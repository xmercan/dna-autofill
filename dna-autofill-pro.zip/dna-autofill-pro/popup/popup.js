document.addEventListener('DOMContentLoaded', async () => {
  const elements = {
    btnOpenPanel: document.getElementById('btnOpenPanel'),
    btnStartStop: document.getElementById('btnStartStop'),
    btnImport: document.getElementById('btnImport'),
    fileInput: document.getElementById('fileInput'),
    statusDot: document.getElementById('statusDot'),
    statusText: document.getElementById('statusText'),
    progressText: document.getElementById('progressText'),
    progressFill: document.getElementById('progressFill'),
    startStopText: document.getElementById('startStopText'),
    statTotal: document.getElementById('statTotal'),
    statSuccess: document.getElementById('statSuccess'),
    statFailed: document.getElementById('statFailed'),
    statDeposit: document.getElementById('statDeposit'),
    logList: document.getElementById('logList')
  };

  let isRunning = false;

  // Başlangıç durumunu al
  await updateStatus();

  // Event listeners
  elements.btnOpenPanel.addEventListener('click', openPanel);
  elements.btnStartStop.addEventListener('click', toggleBot);
  elements.btnImport.addEventListener('click', () => elements.fileInput.click());
  elements.fileInput.addEventListener('change', handleFileImport);

  // Periyodik güncelleme
  setInterval(updateStatus, 1000);

  async function updateStatus() {
    try {
      const response = await chrome.runtime.sendMessage({ action: 'GET_STATUS' });
      
      isRunning = response.isRunning;
      updateUI(response);
    } catch (e) {
      console.error('Status update error:', e);
    }
  }

  function updateUI(data) {
    // Durum göstergesi
    elements.statusDot.className = 'dot' + (data.isRunning ? ' active' : '');
    elements.statusText.textContent = data.isRunning ? 'Çalışıyor...' : 'Hazır';
    elements.startStopText.textContent = data.isRunning ? 'Durdur' : 'Başlat';

    // İlerleme
    const progress = data.progress || 0;
    elements.progressText.textContent = `${data.stats.processed}/${data.stats.total}`;
    elements.progressFill.style.width = `${progress}%`;

    // İstatistikler
    elements.statTotal.textContent = data.stats.total;
    elements.statSuccess.textContent = data.stats.success;
    elements.statFailed.textContent = data.stats.failed;
    elements.statDeposit.textContent = `$${(data.stats.depositTotal || 0).toFixed(2)}`;
  }

  async function openPanel() {
    await chrome.runtime.sendMessage({ action: 'OPEN_PANEL' });
    window.close();
  }

  async function toggleBot() {
    if (isRunning) {
      await chrome.runtime.sendMessage({ action: 'STOP_BOT' });
    } else {
      // Hesap var mı kontrol et
      const { dna_accounts } = await chrome.storage.local.get('dna_accounts');
      if (!dna_accounts || dna_accounts.length === 0) {
        alert('Lütfen önce hesap yükleyin!');
        return;
      }
      await chrome.runtime.sendMessage({ action: 'START_BOT', accounts: dna_accounts });
    }
    await updateStatus();
  }

  function handleFileImport(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      const content = e.target.result;
      await chrome.runtime.sendMessage({ 
        action: 'IMPORT_ACCOUNTS', 
        accounts: content 
      });
      alert('Hesaplar yüklendi!');
      await updateStatus();
    };
    reader.readAsText(file);
  }

  // Logları al ve göster
  async function loadLogs() {
    try {
      const { logs } = await chrome.runtime.sendMessage({ action: 'GET_LOGS' });
      displayLogs(logs.slice(0, 5));
    } catch (e) {}
  }

  function displayLogs(logs) {
    if (logs.length === 0) return;
    
    elements.logList.innerHTML = logs.map(log => `
      <li class="log-item ${log.level}">
        <span class="log-time">${log.timestamp.split(' ')[1]}</span>
        <span class="log-message">${log.message}</span>
      </li>
    `).join('');
  }

  loadLogs();
  setInterval(loadLogs, 2000);
});