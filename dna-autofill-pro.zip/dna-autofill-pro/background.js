// DNA AutoFill Pro - Background Service Worker

class DNABotManager {
  constructor() {
    this.accounts = [];
    this.currentIndex = 0;
    this.isRunning = false;
    this.logs = [];
    this.results = {
      success: [],
      failed: [],
      processing: null
    };
    this.stats = {
      total: 0,
      processed: 0,
      success: 0,
      failed: 0,
      depositTotal: 0
    };
    
    this.initStorage();
    this.setupListeners();
  }

  async initStorage() {
    const data = await chrome.storage.local.get([
      'dna_accounts', 
      'dna_logs', 
      'dna_results',
      'dna_stats',
      'dna_settings'
    ]);
    
    this.accounts = data.dna_accounts || [];
    this.logs = data.dna_logs || [];
    this.results = data.dna_results || { success: [], failed: [], processing: null };
    this.stats = data.dna_stats || { total: 0, processed: 0, success: 0, failed: 0, depositTotal: 0 };
  }

  setupListeners() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      this.handleMessage(request, sender, sendResponse);
      return true;
    });

    chrome.webNavigation.onCompleted.addListener((details) => {
      if (details.url.includes('cp.domainnameapi.com')) {
        this.handlePageLoad(details.tabId, details.url);
      }
    });
  }

  async handleMessage(request, sender, sendResponse) {
    switch (request.action) {
      case 'START_BOT':
        await this.startBot(request.accounts);
        sendResponse({ success: true });
        break;
        
      case 'STOP_BOT':
        await this.stopBot();
        sendResponse({ success: true });
        break;
        
      case 'GET_STATUS':
        sendResponse({
          isRunning: this.isRunning,
          stats: this.stats,
          currentAccount: this.results.processing,
          progress: this.calculateProgress()
        });
        break;
        
      case 'GET_LOGS':
        sendResponse({ logs: this.logs });
        break;
        
      case 'GET_RESULTS':
        sendResponse({ results: this.results });
        break;
        
      case 'CLEAR_DATA':
        await this.clearData();
        sendResponse({ success: true });
        break;
        
      case 'EXPORT_DATA':
        const data = await this.exportData(request.format);
        sendResponse({ data });
        break;
        
      case 'IMPORT_ACCOUNTS':
        await this.importAccounts(request.accounts);
        sendResponse({ success: true });
        break;
        
      case 'UPDATE_ACCOUNT_STATUS':
        await this.updateAccountStatus(request.email, request.status, request.data);
        sendResponse({ success: true });
        break;
        
      case 'OPEN_PANEL':
        await this.openPanel();
        sendResponse({ success: true });
        break;
    }
  }

  calculateProgress() {
    if (this.stats.total === 0) return 0;
    return Math.round((this.stats.processed / this.stats.total) * 100);
  }

  async startBot(accounts) {
    if (this.isRunning) return;
    
    this.accounts = accounts;
    this.currentIndex = 0;
    this.isRunning = true;
    this.stats.total = accounts.length;
    this.stats.processed = 0;
    this.stats.success = 0;
    this.stats.failed = 0;
    
    await this.saveStorage();
    this.addLog('BOT', 'Otomasyon başlatıldı', 'info');
    
    await this.processNextAccount();
  }

  async stopBot() {
    this.isRunning = false;
    this.addLog('BOT', 'Otomasyon durduruldu', 'warning');
    await this.saveStorage();
  }

  async processNextAccount() {
    if (!this.isRunning || this.currentIndex >= this.accounts.length) {
      this.isRunning = false;
      this.addLog('BOT', 'Tüm hesaplar işlendi', 'success');
      await this.saveStorage();
      return;
    }

    const account = this.accounts[this.currentIndex];
    this.results.processing = {
      email: account.email,
      password: account.password,
      status: 'processing',
      step: 'starting',
      startTime: new Date().toISOString()
    };

    this.addLog('PROCESS', `${account.email} işleniyor...`, 'info');
    
    // Yeni sekme aç ve giriş sayfasına git
    const tab = await chrome.tabs.create({
      url: 'https://cp.domainnameapi.com/login',
      active: false // Arka planda çalışsın
    });

    // Content script'e hesap bilgilerini gönder
    setTimeout(async () => {
      try {
        await chrome.tabs.sendMessage(tab.id, {
          action: 'FILL_LOGIN',
          account: account
        });
      } catch (e) {
        this.addLog('ERROR', `Tab mesaj hatası: ${e.message}`, 'error');
      }
    }, 3000);

    this.currentIndex++;
  }

  async handlePageLoad(tabId, url) {
    if (!this.isRunning || !this.results.processing) return;

    if (url.includes('/login')) {
      // Login sayfası - form doldurma işlemi content.js'te
    } else if (url.includes('/activedomains.aspx') || url.includes('/view/domains/')) {
      // Başarılı giriş - deposit bilgisini al
      this.addLog('SUCCESS', `${this.results.processing.email} giriş yaptı`, 'success');
      
      setTimeout(async () => {
        try {
          await chrome.tabs.sendMessage(tabId, {
            action: 'EXTRACT_DEPOSIT'
          });
        } catch (e) {
          // Content script hazır değilse tekrar dene
          setTimeout(async () => {
            await chrome.tabs.sendMessage(tabId, {
              action: 'EXTRACT_DEPOSIT'
            });
          }, 2000);
        }
      }, 2000);
    }
  }

  async updateAccountStatus(email, status, data = {}) {
    const account = this.accounts.find(a => a.email === email);
    if (!account) return;

    const result = {
      email: email,
      password: account.password,
      status: status,
      deposit: data.deposit || 0,
      depositTL: data.depositTL || 0,
      timestamp: new Date().toISOString(),
      error: data.error || null
    };

    if (status === 'success') {
      this.results.success.push(result);
      this.stats.success++;
      this.stats.depositTotal += parseFloat(data.deposit || 0);
      this.addLog('SUCCESS', `${email} - Deposit: $${data.deposit}`, 'success');
      
      // Çıkış yap ve sonraki hesaba geç
      await this.logoutAndContinue();
    } else if (status === 'failed') {
      this.results.failed.push(result);
      this.stats.failed++;
      this.addLog('FAILED', `${email} - Hata: ${data.error}`, 'error');
      
      // Sonraki hesaba geç
      await this.continueToNext();
    }

    this.stats.processed++;
    this.results.processing = null;
    await this.saveStorage();
  }

  async logoutAndContinue() {
    // Tüm tabları bul ve logout yap
    const tabs = await chrome.tabs.query({ url: 'https://cp.domainnameapi.com/*' });
    
    for (const tab of tabs) {
      try {
        await chrome.tabs.sendMessage(tab.id, { action: 'LOGOUT' });
      } catch (e) {
        // Tab kapanmış olabilir
      }
    }

    // Kısa bekleme ve devam et
    setTimeout(() => this.continueToNext(), 2000);
  }

  async continueToNext() {
    // Mevcut tabları kapat
    const tabs = await chrome.tabs.query({ url: 'https://cp.domainnameapi.com/*' });
    for (const tab of tabs) {
      await chrome.tabs.remove(tab.id).catch(() => {});
    }

    // Sonraki hesaba geç
    setTimeout(() => this.processNextAccount(), 1000);
  }

  async importAccounts(accountList) {
    // TXT formatı: email:password veya email,password
    const accounts = accountList.split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0)
      .map(line => {
        const parts = line.includes(':') ? line.split(':') : line.split(',');
        return {
          email: parts[0]?.trim(),
          password: parts[1]?.trim()
        };
      })
      .filter(acc => acc.email && acc.password);

    this.accounts = accounts;
    await this.saveStorage();
    this.addLog('IMPORT', `${accounts.length} hesap içe aktarıldı`, 'info');
  }

  addLog(type, message, level = 'info') {
    const log = {
      id: Date.now(),
      type,
      message,
      level,
      timestamp: new Date().toLocaleString('tr-TR')
    };
    
    this.logs.unshift(log);
    
    // Maksimum 1000 log tut
    if (this.logs.length > 1000) {
      this.logs = this.logs.slice(0, 1000);
    }
    
    // Panel'e gerçek zamanlı bildirim
    this.broadcastToPanel({ action: 'NEW_LOG', log });
  }

  async saveStorage() {
    await chrome.storage.local.set({
      dna_accounts: this.accounts,
      dna_logs: this.logs,
      dna_results: this.results,
      dna_stats: this.stats
    });
    
    this.broadcastToPanel({ 
      action: 'STATUS_UPDATE', 
      data: {
        isRunning: this.isRunning,
        stats: this.stats,
        progress: this.calculateProgress()
      }
    });
  }

  broadcastToPanel(message) {
    // Panel sayfasına mesaj gönder
    chrome.runtime.sendMessage(message).catch(() => {
      // Panel açık değilse hata vermez
    });
  }

  async exportData(format) {
    const data = {
      accounts: this.accounts,
      results: this.results,
      stats: this.stats,
      logs: this.logs,
      exportDate: new Date().toISOString()
    };

    if (format === 'json') {
      return JSON.stringify(data, null, 2);
    } else if (format === 'csv') {
      // CSV formatı
      let csv = 'Email,Password,Status,Deposit USD,Deposit TL,Timestamp,Error\n';
      
      [...this.results.success, ...this.results.failed].forEach(r => {
        csv += `"${r.email}","${r.password}","${r.status}","${r.deposit || 0}","${r.depositTL || 0}","${r.timestamp}","${r.error || ''}"\n`;
      });
      
      return csv;
    }
  }

  async clearData() {
    this.accounts = [];
    this.logs = [];
    this.results = { success: [], failed: [], processing: null };
    this.stats = { total: 0, processed: 0, success: 0, failed: 0, depositTotal: 0 };
    this.currentIndex = 0;
    this.isRunning = false;
    
    await chrome.storage.local.remove([
      'dna_accounts',
      'dna_logs',
      'dna_results',
      'dna_stats'
    ]);
    
    this.addLog('SYSTEM', 'Tüm veriler temizlendi', 'warning');
  }

  async openPanel() {
    const panelUrl = chrome.runtime.getURL('panel/panel.html');
    
    // Yeni pencerede panel aç
    await chrome.windows.create({
      url: panelUrl,
      type: 'popup',
      width: 1400,
      height: 900
    });
  }
}

// Service Worker'ı başlat
const botManager = new DNABotManager();

// Periyodik olarak storage'ı senkronize et
setInterval(() => {
  botManager.saveStorage();
}, 5000);