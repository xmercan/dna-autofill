// DNA AutoFill Pro - Panel Controller

class PanelController {
  constructor() {
    this.currentTab = 'dashboard';
    this.accounts = [];
    this.logs = [];
    this.results = { success: [], failed: [], processing: null };
    this.stats = {};
    this.isRunning = false;
    this.filterDeposit = 'all';
    this.filterStatus = 'all';
    
    this.init();
  }

  async init() {
    this.setupEventListeners();
    this.setupNavigation();
    await this.loadData();
    this.startRealtimeUpdates();
    this.render();
  }

  setupEventListeners() {
    // Bot kontrolü
    document.getElementById('btnStartBot').addEventListener('click', () => this.toggleBot());
    
    // Yedekleme
    document.getElementById('btnBackup').addEventListener('click', () => this.exportBackup());
    document.getElementById('btnRestore').addEventListener('click', () => document.getElementById('hiddenFileInput').click());
    document.getElementById('hiddenFileInput').addEventListener('change', (e) => this.importBackup(e));
    
    // Hesap import
    document.getElementById('btnImportAccounts').addEventListener('click', () => this.showImportModal());
    document.getElementById('btnConfirmImport').addEventListener('click', () => this.confirmImport());
    document.querySelector('.modal-cancel').addEventListener('click', () => this.hideImportModal());
    document.querySelector('.modal-close').addEventListener('click', () => this.hideImportModal());
    document.getElementById('importFile').addEventListener('change', (e) => this.handleFileSelect(e));
    
    // Excel export
    document.getElementById('btnExportExcel').addEventListener('click', () => this.exportToExcel());
    
    // Filtreler
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.filterStatus = e.target.dataset.filter;
        this.renderAccounts();
      });
    });
    
    document.querySelectorAll('.filter-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
        e.target.classList.add('active');
        this.filterDeposit = e.target.dataset.deposit;
        this.renderAccounts();
      });
    });
    
    // Arama
    document.getElementById('accountSearch').addEventListener('input', (e) => {
      this.searchTerm = e.target.value.toLowerCase();
      this.renderAccounts();
    });
    
    // Logları temizle
    document.getElementById('btnClearLogs').addEventListener('click', () => this.clearLogs());
    
    // Ayarlar
    document.getElementById('btnClearAll').addEventListener('click', () => this.clearAllData());
    
    // Runtime mesajları dinle
    chrome.runtime.onMessage.addListener((request) => {
      this.handleRuntimeMessage(request);
    });
  }

  setupNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const tab = e.currentTarget.dataset.tab;
        this.switchTab(tab);
      });
    });
  }

  switchTab(tab) {
    this.currentTab = tab;
    
    // Nav active state
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.toggle('active', item.dataset.tab === tab);
    });
    
    // Tab content
    document.querySelectorAll('.tab-content').forEach(content => {
      content.classList.toggle('active', content.id === `tab-${tab}`);
    });
    
    if (tab === 'accounts') this.renderAccounts();
    if (tab === 'logs') this.renderLogs();
  }

  async loadData() {
    const data = await chrome.storage.local.get([
      'dna_accounts',
      'dna_logs',
      'dna_results',
      'dna_stats',
      'dna_settings'
    ]);
    
    this.accounts = data.dna_accounts || [];
    this.logs = data.dna_logs || [];
    this.results = data.dna_results || { success: [], failed: [], processing: null };
    this.stats = data.dna_stats || { total: 0, processed: 0, success: 0, failed: 0, depositTotal: 0 };
  }

  startRealtimeUpdates() {
    // Her saniye güncelle
    setInterval(async () => {
      await this.loadData();
      this.updateDashboard();
    }, 1000);
  }

  handleRuntimeMessage(request) {
    switch (request.action) {
      case 'STATUS_UPDATE':
        this.stats = request.data.stats;
        this.isRunning = request.data.isRunning;
        this.updateDashboard();
        break;
        
      case 'NEW_LOG':
        this.logs.unshift(request.log);
        if (this.currentTab === 'logs') this.renderLogs();
        break;
        
      case 'LOG_STEP':
        this.updateCurrentProcess(request.email, request.step);
        break;
    }
  }

  updateDashboard() {
    // Stats
    document.getElementById('dashTotal').textContent = this.stats.total || 0;
    document.getElementById('dashSuccess').textContent = this.stats.success || 0;
    document.getElementById('dashFailed').textContent = this.stats.failed || 0;
    document.getElementById('dashDeposit').textContent = `$${(this.stats.depositTotal || 0).toFixed(2)}`;
    
    // Progress
    const progress = this.stats.total > 0 ? Math.round((this.stats.processed / this.stats.total) * 100) : 0;
    document.getElementById('progressPercent').textContent = `${progress}%`;
    document.getElementById('progressFillLarge').style.width = `${progress}%`;
    document.getElementById('progressDetail').textContent = `${this.stats.processed}/${this.stats.total} hesap işlendi`;
    
    const statusBadge = document.getElementById('botStatus');
    statusBadge.textContent = this.isRunning ? 'Çalışıyor' : 'Bekliyor';
    statusBadge.className = 'status-badge ' + (this.isRunning ? 'running' : 'waiting');
    
    // Current process
    const currentProcessEl = document.getElementById('currentProcess');
    if (this.results.processing && this.isRunning) {
      currentProcessEl.style.display = 'block';
      document.getElementById('currentEmail').textContent = this.results.processing.email;
      document.getElementById('currentStep').textContent = this.results.processing.step || 'İşleniyor...';
    } else {
      currentProcessEl.style.display = 'none';
    }
    
    // Recent accounts table
    this.renderRecentAccounts();
  }

  renderRecentAccounts() {
    const tbody = document.getElementById('recentAccountsTable');
    const allResults = [...this.results.success, ...this.results.failed].slice(-10).reverse();
    
    if (allResults.length === 0) {
      tbody.innerHTML = '<tr class="empty-row"><td colspan="6">Henüz işlem yapılmadı</td></tr>';
      return;
    }
    
    tbody.innerHTML = allResults.map(acc => `
      <tr>
        <td>${this.maskEmail(acc.email)}</td>
        <td>
          <button class="copy-btn" onclick="copyToClipboard('${acc.password}')">Şifreyi Kopyala</button>
        </td>
        <td>$${(acc.deposit || 0).toFixed(2)}</td>
        <td><span class="badge badge-${acc.status === 'success' ? 'success' : 'danger'}">${acc.status === 'success' ? 'Başarılı' : 'Başarısız'}</span></td>
        <td>${new Date(acc.timestamp).toLocaleString('tr-TR')}</td>
        <td>
          <button class="copy-btn" onclick="copyToClipboard('${acc.email}')">Mail</button>
          <button class="copy-btn" onclick="copyToClipboard('${acc.email}:${acc.password}')">Tümü</button>
        </td>
      </tr>
    `).join('');
  }

  renderAccounts() {
    const grid = document.getElementById('accountsGrid');
    let filtered = [...this.results.success, ...this.results.failed];
    
    // Status filter
    if (this.filterStatus !== 'all') {
      filtered = filtered.filter(a => a.status === this.filterStatus);
    }
    
    // Deposit filter
    if (this.filterDeposit !== 'all') {
      const min = parseFloat(this.filterDeposit);
      filtered = filtered.filter(a => (a.deposit || 0) >= min);
    }
    
    // Search
    if (this.searchTerm) {
      filtered = filtered.filter(a => a.email.toLowerCase().includes(this.searchTerm));
    }
    
    if (filtered.length === 0) {
      grid.innerHTML = '<div class="empty-state">Hesap bulunamadı</div>';
      return;
    }
    
    grid.innerHTML = filtered.map(acc => `
      <div class="account-card">
        <div class="account-header">
          <div>
            <div class="account-email">${acc.email}</div>
            <span class="badge badge-${acc.status === 'success' ? 'success' : 'danger'} account-status">
              ${acc.status === 'success' ? 'Başarılı' : 'Başarısız'}
            </span>
          </div>
        </div>
        <div class="account-deposit">
          <span>Deposit:</span>
          <span class="deposit-amount">$${(acc.deposit || 0).toFixed(2)}</span>
        </div>
        <div class="account-actions">
          <button class="btn btn-secondary" onclick="copyToClipboard('${acc.email}')">Mail Kopyala</button>
          <button class="btn btn-secondary" onclick="copyToClipboard('${acc.password}')">Şifre Kopyala</button>
          <button class="btn btn-primary" onclick="copyToClipboard('${acc.email}:${acc.password}')">Tümünü Kopyala</button>
        </div>
      </div>
    `).join('');
  }

  renderLogs() {
    const container = document.getElementById('logsContainer');
    
    if (this.logs.length === 0) {
      container.innerHTML = '<div class="empty-state">Henüz log yok</div>';
      return;
    }
    
    container.innerHTML = this.logs.slice(0, 100).map(log => `
      <div class="log-item">
        <span class="log-time">${log.timestamp}</span>
        <span class="log-type ${log.level}">${log.type}</span>
        <span class="log-message">${log.message}</span>
      </div>
    `).join('');
  }

  async toggleBot() {
    if (this.isRunning) {
      await chrome.runtime.sendMessage({ action: 'STOP_BOT' });
    } else {
      if (this.accounts.length === 0) {
        alert('Lütfen önce hesap yükleyin!');
        return;
      }
      await chrome.runtime.sendMessage({ action: 'START_BOT', accounts: this.accounts });
    }
  }

  showImportModal() {
    document.getElementById('importModal').classList.add('active');
  }

  hideImportModal() {
    document.getElementById('importModal').classList.remove('active');
  }

  async confirmImport() {
    const textarea = document.getElementById('importTextarea');
    const content = textarea.value.trim();
    
    if (!content) {
      alert('Lütfen hesap bilgilerini girin!');
      return;
    }
    
    await chrome.runtime.sendMessage({ action: 'IMPORT_ACCOUNTS', accounts: content });
    await this.loadData();
    this.hideImportModal();
    textarea.value = '';
    alert(`${this.accounts.length} hesap yüklendi!`);
  }

  handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      document.getElementById('importTextarea').value = e.target.result;
    };
    reader.readAsText(file);
  }

  async exportBackup() {
    const data = await chrome.runtime.sendMessage({ action: 'EXPORT_DATA', format: 'json' });
    this.downloadFile(data, `dna-backup-${Date.now()}.json`, 'application/json');
  }

  async importBackup(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = JSON.parse(e.target.result);
        
        await chrome.storage.local.set({
          dna_accounts: data.accounts || [],
          dna_logs: data.logs || [],
          dna_results: data.results || { success: [], failed: [], processing: null },
          dna_stats: data.stats || {}
        });
        
        await this.loadData();
        alert('Yedek yüklendi!');
      } catch (err) {
        alert('Yedek dosyası okunamadı: ' + err.message);
      }
    };
    reader.readAsText(file);
  }

  async exportToExcel() {
    const csv = await chrome.runtime.sendMessage({ action: 'EXPORT_DATA', format: 'csv' });
    this.downloadFile(csv, `dna-accounts-${Date.now()}.csv`, 'text/csv');
  }

  downloadFile(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  maskEmail(email) {
    const [user, domain] = email.split('@');
    const maskedUser = user.substring(0, 2) + '***' + user.substring(user.length - 2);
    return `${maskedUser}@${domain}`;
  }

  updateCurrentProcess(email, step) {
    if (this.results.processing) {
      this.results.processing.step = step;
      this.updateDashboard();
    }
  }

  async clearLogs() {
    if (!confirm('Tüm logları silmek istediğinize emin misiniz?')) return;
    
    this.logs = [];
    await chrome.storage.local.set({ dna_logs: [] });
    this.renderLogs();
  }

  async clearAllData() {
    if (!confirm('TÜM verileri silmek istediğinize emin misiniz? Bu işlem geri alınamaz!')) return;
    
    await chrome.runtime.sendMessage({ action: 'CLEAR_DATA' });
    await this.loadData();
    this.render();
  }

  render() {
    this.updateDashboard();
    if (this.currentTab === 'accounts') this.renderAccounts();
    if (this.currentTab === 'logs') this.renderLogs();
  }
}

// Global fonksiyonlar
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    // Toast bildirim gösterilebilir
    console.log('Kopyalandı:', text);
  });
}

// Panel'i başlat
document.addEventListener('DOMContentLoaded', () => {
  new PanelController();
});