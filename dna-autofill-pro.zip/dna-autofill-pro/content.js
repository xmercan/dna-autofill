// DNA AutoFill Pro - Content Script

(function() {
  'use strict';

  class DNAContentHandler {
    constructor() {
      this.currentAccount = null;
      this.isProcessing = false;
      this.setupListeners();
      this.detectPage();
    }

    setupListeners() {
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        this.handleMessage(request, sender, sendResponse);
        return true;
      });
    }

    detectPage() {
      const url = window.location.href;
      
      if (url.includes('/login')) {
        this.pageType = 'login';
      } else if (url.includes('/activedomains.aspx') || url.includes('/view/domains/')) {
        this.pageType = 'dashboard';
      } else {
        this.pageType = 'other';
      }
    }

    async handleMessage(request, sender, sendResponse) {
      switch (request.action) {
        case 'FILL_LOGIN':
          this.currentAccount = request.account;
          await this.fillLoginForm();
          sendResponse({ success: true });
          break;
          
        case 'EXTRACT_DEPOSIT':
          const depositInfo = await this.extractDepositInfo();
          await this.reportSuccess(depositInfo);
          sendResponse({ success: true, data: depositInfo });
          break;
          
        case 'LOGOUT':
          await this.performLogout();
          sendResponse({ success: true });
          break;
      }
    }

    async fillLoginForm() {
      if (this.isProcessing) return;
      this.isProcessing = true;

      try {
        this.logStep('E-posta alanı aranıyor...');
        
        // Kullanıcı adı/email alanı
        const usernameField = await this.waitForElement('#username, #txtUsername, input[name="username"], input[type="text"]');
        if (usernameField) {
          usernameField.value = this.currentAccount.email;
          usernameField.dispatchEvent(new Event('input', { bubbles: true }));
          usernameField.dispatchEvent(new Event('change', { bubbles: true }));
          this.logStep('E-posta dolduruldu');
        }

        await this.delay(500);

        // Şifre alanı
        this.logStep('Şifre alanı aranıyor...');
        const passwordField = await this.waitForElement('#password, #txtPwd, input[name="password"], input[type="password"]');
        if (passwordField) {
          passwordField.value = this.currentAccount.password;
          passwordField.dispatchEvent(new Event('input', { bubbles: true }));
          passwordField.dispatchEvent(new Event('change', { bubbles: true }));
          this.logStep('Şifre dolduruldu');
        }

        await this.delay(500);

        // reCAPTCHA kontrolü
        this.logStep('reCAPTCHA kontrol ediliyor...');
        const recaptchaExists = await this.checkRecaptcha();
        
        if (recaptchaExists) {
          this.logStep('reCAPTCHA tespit edildi, çözülmesi bekleniyor...');
          await this.waitForRecaptchaSolution();
        }

        await this.delay(1000);

        // Login butonuna tıkla
        this.logStep('Giriş yapılıyor...');
        const loginBtn = await this.waitForElement('#btnSubmit, input[type="submit"], button[type="submit"]');
        if (loginBtn) {
          loginBtn.click();
        }

        // Hata kontrolü için bekle
        setTimeout(() => this.checkLoginError(), 3000);

      } catch (error) {
        this.reportError('Form doldurma hatası: ' + error.message);
      }
    }

    async checkRecaptcha() {
      return new Promise((resolve) => {
        const check = () => {
          const recaptcha = document.querySelector('.g-recaptcha, iframe[src*="recaptcha"], #recaptcha');
          resolve(!!recaptcha);
        };
        setTimeout(check, 500);
      });
    }

    async waitForRecaptchaSolution() {
      return new Promise((resolve) => {
        let attempts = 0;
        const maxAttempts = 60; // 60 saniye bekle
        
        const checkInterval = setInterval(() => {
          attempts++;
          
          // reCAPTCHA çözüldü mü kontrol et
          const recaptchaResponse = document.querySelector('[name="g-recaptcha-response"]');
          const isSolved = recaptchaResponse && recaptchaResponse.value.length > 0;
          
          // Veya sayfa değişmiş mi (başarılı giriş)
          const urlChanged = !window.location.href.includes('/login');
          
          if (isSolved || urlChanged || attempts >= maxAttempts) {
            clearInterval(checkInterval);
            if (isSolved) this.logStep('reCAPTCHA çözüldü');
            resolve();
          }
        }, 1000);
      });
    }

    async checkLoginError() {
      // Hata mesajı kontrolü
      const errorElements = document.querySelectorAll('.error, .alert-error, .alert-danger, [class*="error"], [class*="alert"]');
      
      for (const el of errorElements) {
        const text = el.textContent.toLowerCase();
        if (text.includes('invalid') || text.includes('wrong') || text.includes('incorrect') || 
            text.includes('hatalı') || text.includes('yanlış') || text.includes('error')) {
          this.reportError('Geçersiz e-posta veya şifre');
          return;
        }
      }

      // Şifre alanı hala görünüyorsa giriş başarısız olmuş olabilir
      const passwordField = document.querySelector('#password, #txtPwd, input[type="password"]');
      if (passwordField && window.location.href.includes('/login')) {
        // Hala login sayfasındaysak ve şifre alanı varsa hata olabilir
        setTimeout(() => {
          if (window.location.href.includes('/login')) {
            this.reportError('Giriş başarısız olabilir - sayfa değişmedi');
          }
        }, 2000);
      }
    }

    async extractDepositInfo() {
      this.logStep('Deposit bilgisi alınıyor...');
      
      // Sayfanın tam yüklenmesini bekle
      await this.delay(2000);

      // Deposit bilgisini ara - birden fazla seçici dene
      const depositSelectors = [
        'span:contains("Deposit")',
        'td:contains("Deposit")',
        '.enustmenu strong',
        '[class*="deposit"]',
        'span:contains("$")',
        'td span:contains("$")'
      ];

      let depositUSD = '0.00';
      let depositTL = '0.00';

      // Tüm sayfayı tarayıcı ara
      const pageText = document.body.innerText;
      
      // Deposit: $0,04 / 0,00 TL formatı
      const depositMatch = pageText.match(/Deposit\s*[:\\-]?\s*([\\d,\\.]+)\\s*\\$?\\s*\\/\\s*([\\d,\\.]+)\\s*TL/i);
      if (depositMatch) {
        depositUSD = depositMatch[1].replace(',', '.');
        depositTL = depositMatch[2].replace(',', '.');
      } else {
        // Alternatif formatlar
        const usdMatch = pageText.match(/([\\d,\\.]+)\\s*\\$/);
        const tlMatch = pageText.match(/([\\d,\\.]+)\\s*TL/);
        
        if (usdMatch) depositUSD = usdMatch[1].replace(',', '.');
        if (tlMatch) depositTL = tlMatch[1].replace(',', '.');
      }

      // HTML'den doğrudan ara
      const depositElements = document.querySelectorAll('span, td, div, strong');
      depositElements.forEach(el => {
        const text = el.textContent;
        if (text.includes('Deposit') && text.includes('$')) {
          const match = text.match(/([\\d,\\.]+)\\s*\\$/);
          if (match) depositUSD = match[1].replace(',', '.');
        }
      });

      this.logStep(`Deposit bulundu: $${depositUSD} / ${depositTL} TL`);
      
      return {
        deposit: parseFloat(depositUSD) || 0,
        depositTL: parseFloat(depositTL) || 0,
        rawText: pageText.substring(0, 500)
      };
    }

    async performLogout() {
      this.logStep('Çıkış yapılıyor...');
      
      // Logout linkini bul ve tıkla
      const logoutLink = await this.waitForElement('a[href*="logout"], a:contains("Logout"), a:contains("Çıkış"), #ctl00_HeaderMain_Menu_ctl04');
      
      if (logoutLink) {
        logoutLink.click();
      } else {
        // JavaScript logout
        if (typeof __doPostBack === 'function') {
          __doPostBack('ctl00$HeaderMain$Menu$ctl04', '');
        }
      }
    }

    async reportSuccess(depositInfo) {
      await chrome.runtime.sendMessage({
        action: 'UPDATE_ACCOUNT_STATUS',
        email: this.currentAccount.email,
        status: 'success',
        data: depositInfo
      });
    }

    reportError(errorMessage) {
      chrome.runtime.sendMessage({
        action: 'UPDATE_ACCOUNT_STATUS',
        email: this.currentAccount?.email,
        status: 'failed',
        data: { error: errorMessage }
      });
    }

    logStep(message) {
      console.log(`[DNA Bot] ${message}`);
      
      // Background'a bildir
      chrome.runtime.sendMessage({
        action: 'LOG_STEP',
        email: this.currentAccount?.email,
        step: message,
        timestamp: new Date().toISOString()
      });
    }

    // Yardımcı fonksiyonlar
    async waitForElement(selector, timeout = 10000) {
      return new Promise((resolve) => {
        const element = document.querySelector(selector);
        if (element) {
          resolve(element);
          return;
        }

        const observer = new MutationObserver(() => {
          const el = document.querySelector(selector);
          if (el) {
            observer.disconnect();
            resolve(el);
          }
        });

        observer.observe(document.body, { childList: true, subtree: true });

        setTimeout(() => {
          observer.disconnect();
          resolve(document.querySelector(selector));
        }, timeout);
      });
    }

    delay(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }
  }

  // Content handler'ı başlat
  new DNAContentHandler();
})();