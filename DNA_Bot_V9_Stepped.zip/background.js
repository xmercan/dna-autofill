chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START_BOT") {
    // Bulunduğunuz sayfa zaten domainnameapi ise o sayfayı yenileyip orada çalışır. Değilse yeni sekme açar.
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
       if(tabs[0] && tabs[0].url && tabs[0].url.includes("domainnameapi.com")) {
           chrome.tabs.reload(tabs[0].id);
       } else {
           chrome.tabs.create({ url: "https://www.domainnameapi.com/login", active: true });
       }
    });
  }
});