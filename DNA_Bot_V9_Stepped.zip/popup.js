document.addEventListener('DOMContentLoaded', () => {
  const bulkInput = document.getElementById('bulkInput');
  const addBtn = document.getElementById('addBtn');
  const fileInput = document.getElementById('fileInput');
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const clearAllBtn = document.getElementById('clearAllBtn');
  const accountList = document.getElementById('accountList');
  const listCount = document.getElementById('listCount');

  function safeEncode(str) { return btoa(unescape(encodeURIComponent(str))); }
  
  function parseLines(text) {
    let accounts = [];
    let lines = text.split(/\r?\n/);
    for(let line of lines) {
      line = line.trim(); if(!line) continue;
      let tempLine = line.replace(/^https?:\/\//i, '').replace(/^www\./i, '');
      let firstColon = tempLine.indexOf(':');
      if (firstColon === -1) continue;
      let part1 = tempLine.substring(0, firstColon);
      let remainder = tempLine.substring(firstColon + 1);
      let secondColon = remainder.indexOf(':');

      if (secondColon !== -1 && (part1.includes('domain') || part1.includes('.com') || part1.includes('cp.'))) {
        let user = remainder.substring(0, secondColon).trim();
        let pass = remainder.substring(secondColon + 1).trim(); 
        if(user && pass) accounts.push({ username: user, password: safeEncode(pass), status: 'Bekliyor' });
      } else {
        let user = part1.trim();
        let pass = remainder.trim();
        if(user && pass) accounts.push({ username: user, password: safeEncode(pass), status: 'Bekliyor' });
      }
    }
    return accounts;
  }

  function renderUI() {
    chrome.storage.local.get(['savedAccounts', 'botState'], (result) => {
      const accounts = result.savedAccounts || [];
      const state = result.botState || { isRunning: false, currentIndex: 0 };
      
      startBtn.textContent = state.isRunning ? 'BOT ÇALIŞIYOR...' : '▶ BAŞLAT';
      listCount.textContent = `Liste (${accounts.length})`;
      accountList.innerHTML = '';
      
      accounts.forEach((acc, index) => {
        const div = document.createElement('div');
        div.className = 'item ' + (index === state.currentIndex && state.isRunning ? 'current' : '');
        div.innerHTML = `<span>${index+1}. ${acc.username}</span> <span style="color:#aaa;">${acc.status}</span>`;
        accountList.appendChild(div);
      });
    });
  }

  function processData(text) {
    const newAccs = parseLines(text);
    if(newAccs.length > 0) {
      chrome.storage.local.get(['savedAccounts'], (res) => {
        let updated = (res.savedAccounts || []).concat(newAccs);
        chrome.storage.local.set({ savedAccounts: updated }, renderUI);
      });
    }
  }

  addBtn.addEventListener('click', () => {
    let txt = bulkInput.value.trim();
    if(txt) { processData(txt); bulkInput.value = ''; }
  });

  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(evt) { processData(evt.target.result); fileInput.value = ''; };
    reader.readAsText(file);
  });

  startBtn.addEventListener('click', () => {
    chrome.storage.local.get(['savedAccounts', 'botState'], (res) => {
      let state = res.botState || { isRunning: false, currentIndex: 0 };
      state.isRunning = true;
      chrome.storage.local.set({ botState: state }, () => {
        chrome.runtime.sendMessage({ action: "START_BOT" });
        renderUI();
      });
    });
  });

  stopBtn.addEventListener('click', () => {
    chrome.storage.local.get(['botState'], (res) => {
      let state = res.botState || { isRunning: true, currentIndex: 0 };
      state.isRunning = false;
      chrome.storage.local.set({ botState: state }, renderUI);
    });
  });

  clearAllBtn.addEventListener('click', () => {
    chrome.storage.local.set({ savedAccounts: [], botState: { isRunning: false, currentIndex: 0 } }, renderUI);
  });

  setInterval(renderUI, 1000);
  renderUI();
});