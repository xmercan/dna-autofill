
// Kesin Değer Atama Fonksiyonu (Native Setter)
const setNativeValue = (el, val) => {
  const prototype = Object.getPrototypeOf(el);
  const setter = Object.getOwnPropertyDescriptor(prototype, 'value').set;
  setter.call(el, val);
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
};

function safeDecode(str) { return decodeURIComponent(escape(atob(str))); }

window.addEventListener('load', () => {
  chrome.storage.local.get(['botState'], (res) => {
    if (res.botState && res.botState.isRunning) {
      scanForForm();
    }
  });
});

function scanForForm() {
  let attempts = 0;
  
  let scanner = setInterval(() => {
    attempts++;
    
    const isLoginPage = window.location.href.includes('login') || window.location.href.includes('giris');

    // Eğer başarılı giriş yapıldıysa URL değişir
    if (!isLoginPage && !document.querySelector('form')) {
      clearInterval(scanner);
      markSuccessAndStop();
      return;
    }

    // Sadece username kutusunu bularak işe başlıyoruz, pass'ı sonra bulacağız
    let uField = document.querySelector('input[type="text"], input[type="email"], input[name="username"], input[name*="mail"], input[placeholder*="e-mail" i]');
    
    if (uField) {
      clearInterval(scanner);
      executeSteppedInjection();
    } else if (attempts > 30) { 
      clearInterval(scanner);
      showToast("V9 HATA: Form tespit edilemedi.");
    }
  }, 500);
}

function markSuccessAndStop() {
  chrome.storage.local.get(['savedAccounts', 'botState'], (result) => {
    let state = result.botState || { isRunning: false, currentIndex: 0 };
    let accounts = result.savedAccounts || [];
    let lastIndex = state.currentIndex - 1;
    if(lastIndex >= 0 && accounts[lastIndex]) {
      accounts[lastIndex].status = "BAŞARILI";
      chrome.storage.local.set({ savedAccounts: accounts, botState: { isRunning: false, currentIndex: state.currentIndex }});
      showToast("GİRİŞ BAŞARILI! BOT DURDURULDU.", true);
    }
  });
}

function executeSteppedInjection() {
  chrome.storage.local.get(['savedAccounts', 'botState'], (result) => {
    let state = result.botState || { isRunning: false, currentIndex: 0 };
    let accounts = result.savedAccounts || [];
    
    if (state.currentIndex >= accounts.length) {
      chrome.storage.local.set({ botState: { isRunning: false, currentIndex: 0 } });
      showToast("V9: Liste bitti.");
      return;
    }

    let acc = accounts[state.currentIndex];
    let decodedPass = safeDecode(acc.password);

    // ADIM 1: Sadece Kullanıcı Adını Bul ve Yaz
    setTimeout(() => {
      let uF = document.querySelector('input[type="text"], input[type="email"], input[name="username"], input[name*="mail"], input[placeholder*="e-mail" i]');
      if (uF) {
        uF.focus();
        setNativeValue(uF, acc.username);
        uF.blur();
        uF.style.border = '2px solid #ff2a2a'; 
        uF.style.backgroundColor = 'rgba(255, 42, 42, 0.05)';
      }
    }, 200);

    // ADIM 2: Sitenin React bileşeninin güncellenmesi için yarım saniye (500ms) bekle, sonra Şifreyi Bularak Yaz
    setTimeout(() => {
      let pF = document.querySelector('input[type="password"], input[name="password"], input[placeholder*="Password" i], input[placeholder*="şifre" i]');
      if (pF) {
        pF.focus();
        setNativeValue(pF, decodedPass);
        pF.blur();
        pF.style.border = '2px solid #ff2a2a'; 
        pF.style.backgroundColor = 'rgba(255, 42, 42, 0.05)';
      } else {
        // Eğer hala bulunamadıysa (site çok yavaşsa vs) son bir deneme
        console.warn("V9: Şifre alanı ilk denemede bulunamadı.");
      }
    }, 700);

    // ADIM 3: Veriyi kaydet ve Bildirim göster
    setTimeout(() => {
      showToast("V9: " + acc.username + " DOLDURULDU. ONAY BEKLENİYOR.");
      acc.status = "Dolduruldu, Onay Bekleniyor";
      
      // Index'i artır, sayfa manuel yenilendiğinde (giriş butonuna basılınca) sonrakine geçecek.
      state.currentIndex++;
      chrome.storage.local.set({ botState: state, savedAccounts: accounts });
    }, 1000);
    
  });
}

function showToast(message, isSuccess = false) {
  const notif = document.createElement('div');
  notif.textContent = message;
  notif.style.position = 'fixed'; notif.style.top = '20px'; notif.style.right = '20px';
  notif.style.backgroundColor = '#0a0202'; notif.style.color = isSuccess ? '#00ff00' : '#ff2a2a';
  notif.style.padding = '15px'; notif.style.border = '2px solid ' + (isSuccess ? '#00ff00' : '#ff2a2a');
  notif.style.zIndex = '9999999'; notif.style.fontWeight = 'bold';
  notif.style.borderRadius = '5px'; notif.style.boxShadow = '0 0 15px rgba(255,42,42,0.4)';
  document.body.appendChild(notif);
}
